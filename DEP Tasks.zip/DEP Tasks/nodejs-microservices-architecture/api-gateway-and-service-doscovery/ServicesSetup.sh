cd service-login
sudo npm install

cd ..
cd service-orders
sudo npm install

cd ..
cd service-signup
sudo npm install

cd ..
cd service-log
sudo npm install

cd ..
cd api-gateway
sudo npm install