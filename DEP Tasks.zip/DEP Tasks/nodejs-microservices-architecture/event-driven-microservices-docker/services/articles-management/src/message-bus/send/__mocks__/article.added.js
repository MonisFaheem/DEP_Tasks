/* eslint-disable no-unused-vars */
const addedEventMessage = {};

addedEventMessage.send = (article) => {
};

module.exports = addedEventMessage;
