/* eslint-disable no-unused-vars */

module.exports.info = jest.fn((message) => {
});

module.exports.error = jest.fn((message) => {
});
