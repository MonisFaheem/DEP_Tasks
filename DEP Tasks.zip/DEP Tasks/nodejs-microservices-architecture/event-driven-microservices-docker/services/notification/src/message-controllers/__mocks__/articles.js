/* eslint-disable no-unused-vars */
const controller = {};

controller.added = jest.fn(message => true);

module.exports = controller;
