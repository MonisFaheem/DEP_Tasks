/* eslint-disable no-unused-vars */
const email = {};

email.sendArticleAddedEmail = jest.fn((message) => {
});

module.exports = email;
