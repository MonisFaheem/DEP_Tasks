import isAuth from './isAuth';

export default {
  isAuth,
};
