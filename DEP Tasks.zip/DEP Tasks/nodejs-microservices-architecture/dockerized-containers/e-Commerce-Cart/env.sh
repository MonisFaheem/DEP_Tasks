# this environment vairables needs to be set in .env file in applciaiton root directory
# copy this file as .env and add the appropriate values as per environment.
# node & mysql
export NODE_ENV="dev"
export PORT="3004"
export USERNAME="root"
export PASSWORD="root"
export DATABASE="cartDB"
export HOST="mysql"