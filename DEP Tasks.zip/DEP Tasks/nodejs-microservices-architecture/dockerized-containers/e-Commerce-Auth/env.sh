# this environment vairables needs to be set in .env file in applciaiton root directory
# copy this file as .env and add the appropriate values as per environment.
# node & mysql
export NODE_ENV="dev"
export PORT="3001"
export MONGO_HOST="ms_commerce_mongo"
export MONGO_PORT="27017"
export MONGO_USERNAME="root"
export MONGO_PASSWORD="root"
export MONGO_DATABASE="ecommerce"

export EXPRESS_SESSION_SECRET="######################"
export F_CLIENTID="###################"
export F_CLIENTSECRET="###########################"
export F_CALLBACK="/auth/callback/facebook"
export G_CLIENTID="@@@@@@@@@@@@@-###############.apps.%%%%%%%%%%%.com"
export G_CLIENTSECRET="k##########@@@@@@@@@@@@Ub"
export G_CALLBACK="/auth/callback/google"
export L_CLIENTID="##################"
export L_CLIENTSECRET="############"
export L_CALLBACK="/auth/callback/linkedin"

export T_CLIENTID="##################"
export T_CLIENTSECRET="######################"
export T_CALLBACK="/auth/callback/twitter"
export FE_URL="localhost:3000"
export API_KEY='XX0xxxxx-xX0X0XxXXxXxXXXxX0x'
export SMTP_HOST='smtp.mandrillapp.com'
export SMTP_PORT='587'
export SMTP_USER='#############.net'
export SMTP_PASSWORD='##############'
export SID='XX0xxxxx-xX0X0XxXXxXxXXXxX0x'
export TOKEN='XX0xxxxx-xX0X0XxXXxXxXXXxX0x'
export PHONE='+9716156786'
export FE='http://localhost:3000'
export API='http://localhost:3005'
export UPLOAD_DIR='uploads'
export PROFILE_PICTURE_DIR='profile'
export DOCUMENT_UPLOAD_DIR='documents'