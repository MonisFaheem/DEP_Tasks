export default {
	url: 'http://ms-commerce.com/api/v1/',
	register: 'auth/register',
	login: 'auth/login',
	validate_auth: 'auth/validate',
	reset_password: 'auth/reset-password',
	userfetch : 'user/fetch',
	users: 'users',
	user : 'user',
	changeRrole: 'user/change-role'
}
