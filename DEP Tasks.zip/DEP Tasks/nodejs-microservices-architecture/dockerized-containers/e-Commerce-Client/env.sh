# this environment vairables needs to be set in .env file in applciaiton root directory
# copy this file as .env and add the appropriate values as per environment.
# node & mysql
export NODE_ENV="local"
export PORT="3003"