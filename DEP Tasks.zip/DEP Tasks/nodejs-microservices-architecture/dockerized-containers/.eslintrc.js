module.exports = {
  "extends": "airbnb-base",
  "rules": {
      "comma-dangle": 0,
      "no-console": 0,
      "no-unused-vars" :0
    }
};