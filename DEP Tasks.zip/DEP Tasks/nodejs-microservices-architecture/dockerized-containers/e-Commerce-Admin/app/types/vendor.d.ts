
declare namespace NodeJS {
  export interface Global {
    configuration: any
  }
}