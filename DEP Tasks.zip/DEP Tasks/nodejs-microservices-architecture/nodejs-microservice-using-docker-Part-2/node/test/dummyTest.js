var assert = require("assert");

describe('Dummy Test', function(){
    it('should pass', function(){
      assert.ok(true, "It is true!");
    });
});