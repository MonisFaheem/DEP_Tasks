const sql = require('mysql2');
var SqlConn = sql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'CustomerData'

})
SqlConn.connect((err)=>{
    if(err){
        console.log('connection failed: '+JSON.stringify(err,undefined,2));
    } else {
        console.log('databse connected');
    }
})
module.exports=SqlConn