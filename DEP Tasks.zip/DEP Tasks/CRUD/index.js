const connection = require('./DatabaseConnect')
const express = require('express');
const bodyParser =  require('body-parser');
var app = express();


app.use(bodyParser.json())

app.get('/Costumer/:CustomerID' , (req,res)=>{
    connection.query('SELECT * FROM CostumerInfo WHERE CustomerID=?' [req.CustomerID], (err,rows)=>{
     if(err){
         console.log(err)
     }
     else{
         res.send(rows)
     }
 })
 })

 app.delete('/Customer/:CustomerID' , (req,res)=>{
    connection.query('DELETE * FROM CostumerInfo WHERE CustomerID=?' [req.CustomerID], (err,rows)=>{
     if(err){
         console.log(err)
     }
     else{
         res.send(rows)
     }
 })
 })

 app.post('/Customer/:CustomerID' , (req,res)=>{
    var emp = req.body
    var empData = [emp.CustomerName, emp.CustomerEmail]
    connection.query('INSERT INTO CostumerInfo(CustomerName, CustomerEmail) values(?)',[emp], (err,rows)=>{
     if(err){
         console.log(err)
     }
     else{
         res.send(rows)
     }
 })
 })

  app.put('/Costumer/:CustomerID' , (req,res)=>{
    var emp = req.body
    var empData = [emp.CustomerName, emp.CustomerEmail]
    connection.query('UPDATE CostumerInfo SET ? WHERE id- ' +emp.CustomerID,[empData], (err,rows)=>{
     if(err){
         console.log(err)
     }
     else{
        if(rows.affectedRows==0){
        }
        
        else{
                res.send(rows)
            
        }
        
     }
 })
 })

app.listen(3000,()=>console.log('server is running on port 3000'))

