use CustomerData;

CREATE TABLE CostumerInfo (
  CustomerID INT PRIMARY KEY,
  CustomerName VARCHAR(255) NOT NULL,
  CustomerLocation VARCHAR(255),
  CustomerEmail VARCHAR(255) UNIQUE
);
INSERT INTO CostumerInfo (CustomerID, CustomerName, CustomerLocation, CustomerEmail)
VALUES(1,'Hamza','karachi','hamza@gamil.com'),
(2,'Moiz','Karachi','moiz12@gamil.com'),
(3,'Talha','Lahore','TalhaAzam@mail.co');
SELECT * FROM CostumerInfo;

